package newsapiintileotecno.newsapiintileotecno

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
